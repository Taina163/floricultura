<?php
if($_POST){

//cadastro em si
//if($result == "valid"){
    if($_POST['senha']==$_POST['senhaConfirm']){
        require_once __DIR__ . '/../model/usuariosModel.php';
    $user = new usuariosModel();
    $user->setNome($_POST['nome']);
    $user->setEmail($_POST['email']);
    $user->setSenha($_POST['senha']);
    $cadastro = $user->cadastrar();
    
    if($cadastro == 1){
        header('location:../cadastroLogin.php?cod=success');
    }else{
        header('location:../cadastroLogin.php?cod=error');
    }
}else{
    header('location:../cadastroLogin.php?cod=errorSenha');
}}
?>
